import 'package:geolocator/geolocator.dart';
import 'package:location/location.dart' as loc;

  class Location {
  double? lat;
  double? long;

  Future getcurrentlocation() async {

    // this will help to cheq that do we have the permission to use the location or not.
    try {
      final loc.Location location = loc.Location();
      location.requestService();
      Position position = await Geolocator
          .getCurrentPosition(desiredAccuracy: LocationAccuracy.lowest);
      lat = position.latitude;
      long = position.longitude;

    } catch (exception) {
      print(exception);
    }
  }
  double? getlatitude(){
    return lat;
  }
  double? getlongitude(){
    return long;
  }
}