import 'package:flutter/material.dart';
import 'package:fluttericon/meteocons_icons.dart';
import 'package:http/http.dart' as http;
import 'package:weathernews/screens/locationScreen.dart';
import 'dart:convert';
import 'permisssion.dart';

import 'package:weathernews/services/network.dart';

String apikey = '11c8eb01cf64a9229f3bb4591177b5d5';
String airapikey='817010885667eaca04b9d40dd0f225a8b321de031348753d43d2614e6d6dd3ed';
String weatherurl = 'https://api.openweathermap.org/data/2.5/weather';
String forcast = 'http://api.openweathermap.org/data/2.5/forecast';
String fapikey = '3f26d0d5c3cb14376e042fb2e95c4312';
String airurl =  'https://api.ambeedata.com/latest';

class Weathermodel {
  Image getWeatherIcon(int condition) {
    if (condition < 300) {
      return (Image(image: AssetImage('images/thunder.png')));
    } else if (condition < 400) {
      return (Image(image: AssetImage('images/10d.png')));
    } else if (condition < 600) {
      return (Image(image: AssetImage('images/raining.png')));
    } else if (condition < 700) {
      return (Image(image: AssetImage('images/13d.png')));
    } else if (condition < 800) {
      return (Image(image: AssetImage('images/fogcloud.png')));
    } else if (condition == 800) {
      return (Image(image: AssetImage('images/sun.png')));
    } else if (condition <= 804) {
      return (Image(image: AssetImage('images/cloud.png')));
    } else {
      return (Image(image: AssetImage('images/2d.png')));
    }
  }

  Future<dynamic> getcityweather(String? Cityname) async {
    NetworkHelper networkhelper =
        NetworkHelper('$weatherurl?q=$Cityname&appid=$apikey&units=metric');
    var cityweather = await networkhelper.getData();
    return cityweather;
  }

  Future<dynamic> getlocationweather() async {
    Location location = Location();
    await location.getcurrentlocation();
    NetworkHelper networkhelper = NetworkHelper(
        '$weatherurl?lat=${location.getlatitude()}&lon=${location.getlongitude()}&appid=$apikey&units=metric');
    var weatherdata = networkhelper.getData();
    return weatherdata;
  }

  Future<dynamic> getlocationdailyweather() async {
    Location location = Location();
    await location.getcurrentlocation();
    NetworkHelper networkhelper = NetworkHelper(
        '$forcast?lat=${location.getlatitude()}&lon=${location.getlongitude()}&appid=$apikey&units=metric');

    var weatherlocationdata = networkhelper.getData();
    return weatherlocationdata;
  }

  Future<dynamic> getcitydailyweather(String? cityname) async {
    Location location = Location();
    await location.getcurrentlocation();
    NetworkHelper networkelper =
        NetworkHelper('$forcast?q=$cityname&appid=$apikey&units=metric');
    var weathercitydata = networkelper.getData();
    return weathercitydata;
  }


}
