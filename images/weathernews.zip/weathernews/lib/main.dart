import 'package:flutter/material.dart';
import 'package:upgrader/upgrader.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:weathernews/screens/loadinfscreen.dart';
import 'package:weathernews/screens/locationScreen.dart';
import 'package:weathernews/services/permisssion.dart';
import 'package:weathernews/services/weathermodel.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(
          appBarTheme: AppBarTheme(
            iconTheme: IconThemeData(color: Colors.black),
          ),
        ),
        debugShowCheckedModeBanner: false,
        home: LoadingScreen()
    );
  }
}
