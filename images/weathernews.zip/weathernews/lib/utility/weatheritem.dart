
import 'package:flutter/material.dart';

class weatherItem extends StatelessWidget {
  const weatherItem({
    Key? key,
    required this.value, required this.text, required this.unit, required this.imageUrl,
  }) : super(key: key);

  final int value;
  final String text;
  final String unit;
  final String imageUrl;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(text, style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w900,
          fontSize: 15,
          fontFamily: 'Jose'
        ),),
        const SizedBox(
          height: 4,
        ),
        Container(
          padding: const EdgeInsets.all(10.0),
          height: 40,
          width: 40,
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          child: Image.asset(imageUrl, width: 40.00,height: 40,),
        ),
        const SizedBox(
          height: 4,
        ),
        Text(value.toString() + unit, style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w800,
            fontFamily: 'Jose',
          fontSize:15


        ),)
      ],
    );
  }
}