import 'package:flutter/rendering.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:weathernews/screens/searchfile.dart';
import 'package:weathernews/services/weathermodel.dart';
import 'package:weathernews/utility/weatheritem.dart';
import 'package:weathernews/screens/detail_page.dart';

String weatherIconUrl = 'http://openweathermap.org/img/wn/';
String weatherurl = 'https://api.openweathermap.org/data/2.5/weather';
String apikey = '11c8eb01cf64a9229f3bb4591177b5d5';

class LocationScreen extends StatefulWidget {
  final Clocationweather;
  final Flocationweather;

  LocationScreen({this.Clocationweather, this.Flocationweather});

  @override
  State<LocationScreen> createState() => _LocationScreenState();
}

class _LocationScreenState extends State<LocationScreen> {
  String? typedcity;
  Weathermodel weathermodel = Weathermodel();
  List<String> dateList = [];
  List conditionlist = [];

  DateTime today = DateTime.now();
  List<int> dailyEpochDateList = [];
  List dailyDataList = [];
  int? dailySize;
  List<int> dailyWeekDayDateList = [];
  List<int> dailyDayDateList = [];
  List<int> dailyMonthDateList = [];

  List dailyHumidity = [];
  List dailyDescription = [];
  List dailywind = [];
  List dailyFeelslike = [];
  List dailyMinTempList = [];
  List dailyMaxTempList = [];
  List dailyTempList = [];

  List<String> dailyicon = [];
  var feelslike;
  var humidity;
  var wind;
  var maxtemp;
  List datadailylist = [];
  var datadailylength;
  List datelist = [];

  List dailymain = [];

  int? temperature;
  var weatherIcon;
  String? cityName;
  var conditions;
  String? weatherstatus;
  List<String> dailyweawterstatus = [];
  var weekday = {
    1: 'Monday',
    2: 'Tuesday',
    3: 'Wednesday',
    4: 'Thursday',
    5: 'Friday',
    6: 'Saturday',
    7: 'Sunday'
  };

  var weekday1 = {
    1: 'Mon',
    2: 'Tue',
    3: 'Wed',
    4: 'Thu',
    5: 'Fri',
    6: 'Sat',
    7: 'Sun'
  };
  var monthValue = {
    1: 'Jan',
    2: 'Feb',
    3: 'Mar',
    4: 'Apr',
    5: 'May',
    6: 'Jun',
    7: 'Jul',
    8: 'Aug',
    9: 'Sep',
    10: 'Oct',
    11: 'Nov',
    12: 'Dec'
  };
  final _controller = TextEditingController();
  List Date = [];
  List Day = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    UpdateUi(widget.Clocationweather);
    Updatedailyweather(widget.Flocationweather);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _controller.dispose();
    super.dispose();
  }

  void UpdateUi(dynamic weatherinfo) {
    setState(() {
      if (weatherinfo == null) {
        temperature = 0;
        weatherIcon = 'Error';
        cityName = "unable to load ";
        weatherstatus = 'Error';
        wind = 0;
        humidity = 0;
        maxtemp = 0;
        feelslike = 0;
        return;
      } else {
        double temp = weatherinfo['main']['temp'];
        temperature = temp.toInt();
        conditions = weatherinfo['weather'][0]['id'];
        weatherIcon = weathermodel.getWeatherIcon(conditions);
        cityName = weatherinfo['name'];
        weatherstatus = weatherinfo['weather'][0]['main'];
        double windy = weatherinfo['wind']['speed'];
        wind = windy.toInt();
        humidity = weatherinfo['main']['humidity'];
        double mtemp = weatherinfo['main']['temp_max'];
        maxtemp = mtemp.toInt();
        double feels = weatherinfo['main']['feels_like'];
        feelslike = feels.toInt();
      }
    });
  }

  void Updatedailyweather(dynamic dailyweatherinfo) {
    setState(() {
      datadailylist = dailyweatherinfo['list'];
      datadailylength = datadailylist.length;

      for (int i = 0; i < datadailylength; i++) {
        dailyTempList.add(dailyweatherinfo['list'][i]['main']['temp']);
        dailyMinTempList.add(dailyweatherinfo['list'][i]['main']['temp_min']);
        dailyMaxTempList.add(dailyweatherinfo['list'][i]['main']['temp_min']);
        dailyicon.add(dailyweatherinfo['list'][i]['weather'][0]['icon']);
        dailyweawterstatus
            .add(dailyweatherinfo['list'][i]['weather'][0]['main']);
        dailyHumidity.add(dailyweatherinfo['list'][i]['main']['humidity']);
        dailywind.add(dailyweatherinfo['list'][i]['wind']['speed']);
        conditionlist.add(dailyweatherinfo['list'][i]['weather'][0]['id']);
        dailyEpochDateList.add(dailyweatherinfo['list'][i]['dt']);

        dailyDayDateList.add(
            DateTime.fromMillisecondsSinceEpoch(dailyEpochDateList[i] * 1000)
                .day
                .toInt());
        Date = dailyDayDateList.toSet().toList();

        dailyWeekDayDateList.add(
            DateTime.fromMillisecondsSinceEpoch(dailyEpochDateList[i] * 1000)
                .weekday
                .toInt());
        Day = dailyWeekDayDateList.toSet().toList();
        dailyMonthDateList.add(
            DateTime.fromMillisecondsSinceEpoch(dailyEpochDateList[i] * 1000)
                .month
                .toInt());
      }
    });
  }

  void searchcity() async {
    var weatherdata = await weathermodel.getcityweather(typedcity);
    var dcityweather = await weathermodel.getcitydailyweather(typedcity);
    UpdateUi(weatherdata);
    dailyTempList = [];
    dailyicon = [];
    dateList = [];
    dailyDescription = [];
    dailyFeelslike = [];
    dailyHumidity = [];
    dailyMaxTempList = [];
    dailyMinTempList = [];
    dailyDayDateList = [];
    dailyMonthDateList = [];

    dailyWeekDayDateList = [];

    Updatedailyweather(dcityweather);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //backgroundColor: Color(0xFFEEF5ED),
      body: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('images/backee.jpg'), fit: BoxFit.fill),
        ),
        child: Padding(
          padding: EdgeInsets.all(10.0),
          child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Image(
                      height: 100.0,
                      image: AssetImage('images/50d.png'),
                    ),

                    SizedBox(
                      width: 220.0,
                    ),
                    IconButton(
                      onPressed: () async {
                        typedcity = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return Searchtextbar();
                            },
                          ),
                        );
                        searchcity();
                      },
                      icon: Icon(
                        Icons.add,
                        color: Colors.white,
                        size: 30.0,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10.0,
                ),
                SizedBox(
                  height: 0.0,
                ),
                Text(
                  '$cityName',
                  style: TextStyle(
                      fontFamily: "Jose",
                      fontSize: 30.0,
                      color: Colors.white,
                      fontWeight: FontWeight.w900),
                ),
                Text(
                  ' ${DateFormat.yMMMEd().format(DateTime.now())}',
                  style: TextStyle(
                      fontFamily: "Ama",
                      fontSize: 20.0,
                      color: Colors.white,
                      fontWeight: FontWeight.w600),
                ),
                SizedBox(
                  height: 10.0,
                ),
                Container(
                  width: 200.0,
                  height: 100.0,
                  color: Colors.transparent,
                  // decoration: BoxDecoration(
                  //      color: Colors.transparent,
                  //      borderRadius: const BorderRadius.all(
                  //        Radius.circular(20.0),
                  //      ),
                  //      boxShadow: [
                  //        BoxShadow(
                  //            color: Colors.black.withOpacity(1),
                  //            blurRadius: 5.0,
                  //            spreadRadius: -20.0,
                  //            offset: const Offset(0, 18))
                  //      ]),
                  child: Stack(
                    children: [
                      Positioned(
                        left: 15.0,
                        bottom: -8,
                        child: Text(
                          weatherstatus!,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 30.0,
                            fontFamily: "Jose",
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Positioned(
                        right: -3,
                        bottom: 30.0,
                        child: Text(
                          "$temperature°C",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 35.0,
                              fontWeight: FontWeight.w900,
                              fontFamily: "Jose"),
                        ),
                      ),
                      Positioned(
                        width: 70.0,
                        left: 6.0,
                        top: -1,
                        child: weathermodel.getWeatherIcon(conditions),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 25.0),
                Container(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // weatherItem(
                    //     value: feelslike,
                    //     text: 'feelsLike',
                    //     unit: '°',
                    //     imageUrl: 'images/feels.png'),
                    weatherItem(
                        value: humidity,
                        text: 'Humidity',
                        unit: '%',
                        imageUrl: 'images/humidity.png'),
                    weatherItem(
                        value: maxtemp,
                        text: 'Max.Temp',
                        unit: '°C',
                        imageUrl: 'images/hot.png'),
                    weatherItem(
                        value: wind,
                        text: 'wind',
                        unit: ' Km/h',
                        imageUrl: 'images/wind.png'),
                  ],
                )),
                SizedBox(
                  height: 30.0,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      'Today',
                      style: TextStyle(
                          fontFamily: 'Ama',
                          fontWeight: FontWeight.w900,
                          fontSize: 25,
                          color: Colors.white),
                    ),
                    Text(
                      'Next 5 Days',
                      style: TextStyle(
                          fontFamily: 'Ama',
                          fontWeight: FontWeight.w800,
                          fontSize: 25,
                          color: Colors.white),
                    )
                  ],
                ),
                SizedBox(height: 20.0),
                Expanded(
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: 6,
                    itemBuilder: (context, index) {
                      return Container(

                        padding: EdgeInsets.symmetric(vertical: 5.0),
                        margin: EdgeInsets.only(
                            right: 12.0, bottom: 40.0, top: 10.0),
                        width: 100.0,

                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                  offset: const Offset(0, 1),
                                  blurRadius: 0.5,
                                  color: Colors.black)
                            ],
                            borderRadius:
                                BorderRadius.all(Radius.circular(10.0))),
                        child: Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment: CrossAxisAlignment.center
                            ,

                            children: [
                              Text(
                                '${dailyTempList[index].toInt()}°C',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Jose',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 15),
                              ),
                              Text(
                                '${dailyweawterstatus[index]}',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Jose',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 15),
                              ),
                              Container(
                                  width: 50,
                                  height: 50,
                                  child: weathermodel
                                      .getWeatherIcon(conditionlist[index])),
                              Text(
                                '${weekday1[Day[index]]},${Date[index]}',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Jose',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 15),
                              )
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),


              ],
            ),
          ),
        ),
      ),
    );
  }
}
// child: Column(
//   mainAxisAlignment: MainAxisAlignment.center,
//
//   children: [
//     Text('${dailyTempList[index].toInt()}°C',
//       style: TextStyle(
//       color:Colors.white,
//       fontFamily: 'Poppins',
//       fontWeight: FontWeight.w500,
//         fontSize: 18.0
//     ),
//     ),
//     Text('${dailyweawterstatus[index]}',style: TextStyle(
//       color: Colors.white
//     ),),
//     weathermodel.getWeatherIcon(conditionlist[index]),// if doenst work we will
//     //Image(image: NetworkImage('$weatherIconUrl${dailyicon[index]}@4x.png')),
//     Text('${weekday1[Day[index]]},${Date[index]}',style: TextStyle(
//       color: Colors. white
//     ),)
//   ],
//
// ),
