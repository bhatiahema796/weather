import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:http/http.dart' as http;

class Searchtextbar extends StatefulWidget {
  const Searchtextbar({Key? key}) : super(key: key);


  @override
  State<Searchtextbar> createState() => _SearchtextbarState();
}

class _SearchtextbarState extends State<Searchtextbar> {



  TextEditingController _controller = TextEditingController();
  String? cityname;





  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller.addListener(() {setState(() {

    });});
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        title: const Text(
          'Manage cities',
          style: TextStyle(
              color: Colors.black,
              fontFamily: 'Poppins',
              fontSize: 30.0,
              fontWeight: FontWeight.bold),
        ),
      ),
      body: Container(
        padding: const EdgeInsets.all(20.0),
        child: TextField(
          controller: _controller,
          keyboardType: TextInputType.name,
          style: const TextStyle(
              color: Colors.black, fontSize: 16.0, fontFamily: 'poppins'),
          showCursor: true,
          cursorColor: Colors.black,
          onChanged: (value){
            cityname=value;
          },
          decoration: InputDecoration(
            suffixIcon: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              mainAxisSize: MainAxisSize.min,
              children: [
                _controller.text.isEmpty
                    ? Container(
                        width: 0,
                        height: 0,
                      )
                    : IconButton(
                        onPressed: () {
                          _controller.clear();
                        },
                        icon: Icon(Icons.close),
                        color: Colors.black,
                      ),
                IconButton(
                  onPressed: () {
                   Navigator.pop(context,cityname);
                  },
                  icon: Icon(Icons.search),
                  color: Colors.black,
                )
              ],
            ),
            hintText: 'Search the City',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(15.0)),
              borderSide: BorderSide(width: 2, color: Colors.black),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(width: 1, color: Colors.black),
              borderRadius: BorderRadius.all(Radius.circular(15.0)),
            ),
          ),
        ),
      ),
    );
  }
}
