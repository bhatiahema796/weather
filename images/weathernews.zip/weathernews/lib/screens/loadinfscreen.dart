import 'package:flutter/material.dart';
import 'package:weathernews/services/weathermodel.dart';
import 'locationScreen.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:weathernews/services/permisssion.dart';

class LoadingScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _LoadingScreenState();
  }
}

class _LoadingScreenState extends State<LoadingScreen> {
  @override
  void initState() {
    super.initState();
    //getLocationData();
  }

  void getLocationData() async {
    Location location = Location();
    await location.getcurrentlocation();
    print('lat=${location.long}');
    print('loc=${location.lat}');
    Weathermodel weatherData = Weathermodel();
    var weathervalue = await weatherData.getlocationweather();
    var dailydata = await weatherData.getlocationdailyweather();
    print(weathervalue);
    print('hello');
    print(dailydata);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          return LocationScreen(
            Clocationweather: weathervalue,
            Flocationweather: dailydata,
          );
        },
      ),
    );

  }

  @override
    Widget build(BuildContext context) {


    return Scaffold(
      body: Container(

              decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('images/start.jpg'), fit: BoxFit.fill),

                ),
        child: Center(
      child: SpinKitCircle(
      color: Colors.black,
        size: 100.0,
      ),
    ),
      ),


    );

    // return Container(
    //   decoration: BoxDecoration(
    //     image: DecorationImage(
    //         image: AssetImage('images/start.jpg'), fit: BoxFit.fill),
    //   ),
    //
  }
}
